// elementos del html
const button         = document.getElementById("btnGuardar");
const btnSincronizar = document.getElementById("btnSincronizar");
const lista          = document.getElementById("lista");
const mensaje        = document.getElementById("mensaje");

// aqui se guardan los productos mientras la pagina esta abierta
let productos = [];

const URL = "http://localhost:3000/productos";

// muestra un mensaje en pantalla y lo borra a los 3 segundos
function mostrarMensaje(texto, tipo = "ok") {
    mensaje.textContent = texto;
    mensaje.style.color = tipo === "ok" ? "#421709" : "#c0392b";
    setTimeout(() => { mensaje.textContent = ""; }, 3000);
}

// si habia productos guardados los carga al abrir la pagina
const productosGuardados = localStorage.getItem("productos");

if (productosGuardados) {
    productos = JSON.parse(productosGuardados);
    productos.forEach((producto) => crearProducto(producto));
    console.log(`productos cargados: ${productos.length}`);
}

// trae los productos del servidor y los muestra en pantalla
async function obtenerProductos() {
    try {
        const respuesta = await fetch(URL);
        const datos     = await respuesta.json();

        console.log("respuesta del servidor:", datos);

        // limpia lo que habia antes de mostrar lo nuevo
        lista.innerHTML = "";
        productos = datos;
        localStorage.setItem("productos", JSON.stringify(productos));
        productos.forEach((producto) => crearProducto(producto));

        mostrarMensaje(`${datos.length} productos cargados desde la API`);

    } catch (error) {
        console.log("no se pudo conectar:", error);
        mostrarMensaje("no se pudo conectar con la API", "error");
    }
}

// envia un producto nuevo al servidor con POST
async function agregarProductos(producto) {
    try {
        const respuesta = await fetch(URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(producto)
        });

        const datos = await respuesta.json();
        console.log("guardado en servidor:", datos);
        return datos;

    } catch (error) {
        console.log("error al guardar:", error);
        mostrarMensaje("no se pudo guardar en la API", "error");
    }
}

// borra un producto del servidor con DELETE
async function eliminarProductoServidor(id) {
    try {
        await fetch(`${URL}/${id}`, { method: "DELETE" });
        console.log("eliminado del servidor, id:", id);

    } catch (error) {
        console.log("error al eliminar:", error);
        mostrarMensaje("no se pudo eliminar en la API", "error");
    }
}

// actualiza un producto en el servidor con PUT
async function actualizarProducto(id, productoActualizado) {
    try {
        const respuesta = await fetch(`${URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(productoActualizado)
        });

        const datos = await respuesta.json();
        console.log("actualizado en servidor:", datos);

    } catch (error) {
        console.log("error al actualizar:", error);
        mostrarMensaje("no se pudo actualizar en la API", "error");
    }
}

// click en guardar
button.addEventListener("click", async () => {

    const nombreProducto = document.getElementById("nombre").value;
    const precioProducto = document.getElementById("precio").value;

    // revisa que los campos no esten vacios
    if (nombreProducto.trim() === "" || precioProducto.trim() === "") {
        mostrarMensaje("completa todos los campos", "error");
        return;
    }

    // el precio tiene que ser mayor a 0
    if (Number(precioProducto) <= 0) {
        mostrarMensaje("el precio debe ser mayor a 0", "error");
        return;
    }

    const producto = {
        nombre: nombreProducto,
        precio: precioProducto
    };

    const nuevoProducto = await agregarProductos(producto);

    // si el servidor fallo no hace nada mas
    if (!nuevoProducto) return;

    productos.push(nuevoProducto);
    localStorage.setItem("productos", JSON.stringify(productos));
    crearProducto(nuevoProducto);

    mostrarMensaje(`"${nuevoProducto.nombre}" guardado`);
    console.log("agregado:", nuevoProducto);

    document.getElementById("nombre").value = "";
    document.getElementById("precio").value = "";
    document.getElementById("nombre").focus();
});

// click en sincronizar
btnSincronizar.addEventListener("click", () => {
    obtenerProductos();
});

// crea un li con el producto y lo agrega a la lista
function crearProducto(producto) {

    const item = document.createElement("li");

    // span separado para que el appendChild del boton no lo pise
    const span = document.createElement("span");
    span.textContent = `${producto.nombre} — $${Number(producto.precio).toLocaleString("es-CO")}`;

    const botonEliminar = document.createElement("button");
    botonEliminar.textContent = "Eliminar";

    botonEliminar.addEventListener("click", () => {
        lista.removeChild(item);

        // filtra por id para no borrar productos con el mismo nombre
        productos = productos.filter((p) => p.id !== producto.id);
        localStorage.setItem("productos", JSON.stringify(productos));

        eliminarProductoServidor(producto.id);

        mostrarMensaje(`"${producto.nombre}" eliminado`);
        console.log("eliminado:", producto);
    });

    item.appendChild(span);
    item.appendChild(botonEliminar);
    lista.appendChild(item);
}