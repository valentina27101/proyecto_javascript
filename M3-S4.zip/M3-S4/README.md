# Productos — M3-W4

Aplicación web para agregar, eliminar y sincronizar productos usando DOM, localStorage y una API local con JSON Server.

---

## Estructura del proyecto

```
M3-W4/
├── node_modules/
├── public/
│   ├── evidencias/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── db.json
├── package-lock.json
└── package.json
```

---

## Qué hace la app

- Agrega productos con nombre y precio desde un formulario
- Los muestra en una lista con botón para eliminar cada uno
- Guarda los datos en `localStorage` para que no se pierdan al recargar
- Se conecta a un servidor local (JSON Server) para hacer GET, POST y DELETE
- El botón **Sincronizar con API** trae los productos del servidor y actualiza la lista

---

## Cómo correrla

**1. Instalar dependencias** (si es la primera vez)

```bash
npm install
```

**2. Levantar el servidor**

```bash
npx json-server --watch db.json --port 3000
```

**3. Abrir `public/index.html`** en el navegador (con Live Server o similar)

> La app espera el servidor en `http://localhost:3000/productos`

---

## Endpoints que usa

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/productos` | trae todos los productos |
| POST | `/productos` | guarda un producto nuevo |
| DELETE | `/productos/:id` | elimina un producto por id |
| PUT | `/productos/:id` | actualiza un producto (función lista, sin botón en UI) |

---

## Validaciones

- No deja guardar si algún campo está vacío
- No deja guardar si el precio es 0 o negativo
- Los mensajes de error y éxito aparecen en pantalla y desaparecen solos a los 3 segundos

---

## Tecnologías

- HTML5, CSS3, JavaScript ES6+
- Fetch API con `async/await` y `try/catch`
- `localStorage` para persistencia en el navegador
- JSON Server como API local

---

## Autor

**Valentina Pacheco**. Proyecto Práctica de DOM, localStorage y Fetch API.